
public class EnemyUnitService 
{
    
    private EnemyUnitView _enemyUnitView;

    public EnemyUnitService(EnemyUnitView enemyUnitView)
    {
        _enemyUnitView = enemyUnitView;
    }
}
