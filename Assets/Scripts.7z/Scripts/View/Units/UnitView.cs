using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnitView : MonoBehaviour
{
    public void MoveToTarget()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
